const http = require('http');
const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

// Instantiate an event emitter
class MyEmitter extends EventEmitter {}
const myEmitter = new MyEmitter();

// Define an event and an associated listener
myEmitter.on('pageAccess', (route) => {
  console.log(`Page accessed: ${route}`);
});

const server = http.createServer((req, res) => {
  // Access the URL requested by the browser
  const requestedUrl = req.url;

  // Parse the URL
  const url = new URL(requestedUrl, `http://${req.headers.host}`);
  const pathName = url.pathname;

  // Determine the file path based on the route
  let filePath;
  if (pathName === '/') {
    filePath = path.join(__dirname, 'views', 'home.html');
    myEmitter.emit('pageAccess', '/');
  } else if (pathName === '/about') {
    filePath = path.join(__dirname, 'views', 'about.html');
    myEmitter.emit('pageAccess', '/about');
  } else if (pathName === '/contact') {
    filePath = path.join(__dirname, 'views', 'contact.html');
    myEmitter.emit('pageAccess', '/contact');
  } else {
    filePath = path.join(__dirname, 'views', 'notfound.html');
    myEmitter.emit('pageAccess', 'Not Found');
  }

  // Use fs.readFile to read the HTML file from disk
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('File not found!');
    } else {
      res.writeHead(200, { 'Content-Type': 'text/html' });

      // Pass the HTML data to response.write
      res.write(data);

      // Finish the response
      res.end();
    }
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
